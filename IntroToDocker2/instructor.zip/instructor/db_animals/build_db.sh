#!/bin/bash

mysql --user=root --password=badpass < /tmp/animals.sql

