<?php
	#
	# store the database connection parameters
	#
	$trs_db_uid="root";
	$trs_db_pw="beer";
	$trs_db_host="localhost";
	$trs_db_db="reservations";
?>
