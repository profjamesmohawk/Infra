<html>
 <head>
  <title>TRS</title>
 </head>
 <body>

	<?php
	echo phpinfo();
	print_r(ini_get_all());
	?>
</body>
</html>
